#1. Descargar el código fuente de X-Road, esta traición corresponde a la versión 6.16
https://github.com/ria-ee/X-Road/releases

#2. Copiar los archivos de traducción al código fuente
cp ESfiles-6.16/center-ui/* xroad-code/src/center-ui/config/locales/;
cp ESfiles-6.16/common-ui/* xroad-code/src/common-ui/config/locales/;
cp ESfiles-6.16/proxy-ui/* xroad-code/src/proxy-ui/config/locales/;
cd xroad-code/src;

#3. Cambiar la variable  config.i18n.default_locale = :en 
# por config.i18n.default_locale = :es dentro de los archivos: 

xroad-code/src/center-service/config/application.rb 
xroad-code/src/center-ui/config/application.rb
xroad-code/src/proxy-ui/config/application.rb

#4. Luego compilar el código fuente de acuerdo a las instrucciones del proyecto X-Road
# https://github.com/ria-ee/X-Road/blob/44d69e017541fe25f7cdfcd541a5d74d66ff5566/src/BUILD.md

#5. Una vex terminada la compilacion copiar los paquetes de instalación 

Paquetes .DEB desde xroad-code/src/packets/ 
Pquetes  .RPM desde xroad-code/src/packets/xroad/redhat/RMPS/

Estos mimos paquetes ya compilados estan disponibles en: 
http://tenoli.gobiernoelectronico.gob.sv/debs/

